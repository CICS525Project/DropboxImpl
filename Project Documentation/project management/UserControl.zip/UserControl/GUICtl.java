package UserControl;

import javafx.stage.Stage;

public class GUICtl {

	public static Stage mainStage = new Stage();
	
	public static Stage getStage(){
		return mainStage;
	}

}
